<?php
/*
Plugin Name: nvt_custom_bp_profile_nav
Plugin URI: https://nvtam.com/
Description: Add Company tab to BuddyBoss profile nav
Version: 1.0
Author: NguyenTam
Author URI: https://nvtam.com/
License: GPL
*/
if (!class_exists("Nvt_Custom_BP_Profile_Nav")) {
    class Nvt_Custom_BP_Profile_Nav
    {
        function __construct()
        {
            if (!function_exists('add_shortcode')) {
                return;
            }
            add_shortcode( 'nvt_custom_bp_profile_nav' , array(&$this, 'create_shortcode_func') );
        }
        function create_shortcode_func($atts=array(), $content=null)
        {
            extract(shortcode_atts(array('text' => 'Companies'), $atts));
            return ncbpn_show_tab($text);
        }
    }
}
function ncbpn_load()
{
    global $mfpd;
    $mfpd = new Nvt_Custom_BP_Profile_Nav();
}
add_action( 'plugins_loaded', 'ncbpn_load' );
function ncbpn_show_tab($text){
    echo "Will show list company here !!";
}
function ncbpn_add_admin_menu()
{
    add_menu_page (
        'Custom BP Profile Nav',
        'Custom BP Profile Nav',
        'manage_options',
        'nvt_custom_bp_profile_nav',
        'ncbpn_view_guid',
        '',
        '2'
    );
}
function ncbpn_view_guid()
{
    echo '<h1>Shortcode is: [nvt_custom_bp_profile_nav]</h1>';
    
}
add_action('admin_menu', 'ncbpn_add_admin_menu');
function ncbpn_add_tabs(){
    global $bp;
    bp_core_new_nav_item( array( 
        'name' => 'Company', 
        'slug' => 'company', 
        'position' => 45,
        'screen_function' => 'ibenic_budypress_recent_posts',
        'show_for_displayed_user' => true,
        'item_css_id' => 'ibenic_budypress_recent_posts'
    ) );
}
add_action( 'bp_setup_nav', 'ncbpn_add_tabs', 1000 );
function ibenic_budypress_recent_posts () {

    add_action( 'bp_template_content', 'ncbpn_recent_posts_content' );
    bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
/*function ncbpn_recent_posts_title() {
    echo "Company";
}*/


/************************************************************************************************************************************************************
 *                                      add css and js file
 ************************************************************************************************************************************************************/
function npp_enqueue_scripts_and_styles()
{
    wp_register_style( 'bootstrap.min', plugin_dir_url( __FILE__ ).'css/bootstrap.min.css' );
    wp_enqueue_style( 'bootstrap.min' );

    wp_register_style( 'plugin_css', plugin_dir_url( __FILE__ ).'css/plugin_css.css' );
    wp_enqueue_style( 'plugin_css' );

    wp_register_script( "bootstrap_js", WP_PLUGIN_URL.'/nvt_custom_bp_profile_nav/js/bootstrap.min.js', array('jquery') );
    
    // đăng ký ajax và script
    wp_register_script( "js", WP_PLUGIN_URL.'/nvt_custom_bp_profile_nav/js/script_plugin.js', array('jquery') );
    wp_localize_script( 'js', 'ajaxobject', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ), 'rootURL'=>site_url()));  
    


    wp_enqueue_script( 'bootstrap_js' );
    wp_enqueue_script( 'js' );
}
add_action( 'wp_enqueue_scripts', 'npp_enqueue_scripts_and_styles' );


/************************************************************************************************************************************************************
 *                                      add Isaac Newton
 ************************************************************************************************************************************************************/
add_action("wp_ajax_form", "handle_form");
add_action("wp_ajax_nopriv_form", "handle_form");
function handle_form(){

  //  name,
  //  address,
  //  phone,
  //  website,
  //  description,


    wp_send_json( array('code'=> 200, 'msg'=>'OK men' . $_POST['name'] . '<br/>' .$_POST['address'] . '<br/>' . $_POST['phone'] . '<br/>'. $_POST['website'] . '<br/>'. $_POST['description'] ) );

    global $wpdb;
    $wpdb -> insert


}


//  form bootstrap 
function ncbpn_recent_posts_content() {

  echo '
 
<div class="text-right">
<button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModalCenter">Add Company</button>
</div>

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="exampleModalLongTitle">Add Company</h6>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="formGroupExampleInput">Company Name</label>
            <input type="text" class="form-control" id="name" placeholder="Name of company">
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput2">Address</label>
            <input type="text" class="form-control" id="address" placeholder="Address">
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput2">Tel</label>
            <input type="text" class="form-control" id="phone" placeholder="Tel number">
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput2">Website</label>
            <input type="text" class="form-control" id="website" placeholder="Company website">
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput2">Infomation</label>
            <input type="text" class="form-control" id="description" placeholder="Short description">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-sm" id="submit">Save</button>
      </div>
    </div>
  </div>
</div>

<div class="content">
    <p>list company here</p>
</div>


';
 
    
}



// function FunctionName()
// {
//   $label = array(
//     'name' => "Company",
//     'singular_name'=> "Company",
//     'add_new' => 'Add Item',
//     'all_items' => 'All Item',
//     'add_new_item' => 'New Item',
//     'edit_item' => 'Edit Item',
//     'new_item' => 'New Item',
//     'view_item' => 'View Item',
//     'search_item' => 'Search Company',
//     'not_found' => 'No items found',
//     'not_found_in_trash' => 'No items found in trash',
//     'parent_item_colon' => 'Parent Item'
//   );
//   $args = array(
//       'labels' => $label ,
//       'public' => true,
//       'has_archive' => true ,
//       'publicly_queryable' => true,
//       'query_var' => true,
//       'rewrite' => true ,
//       'capability_type' => 'post' ,
//       'hierarchical' => false ,
//       'supports' => array(
//         'title',
//         'edittor',
//         'excerpt',
//         'thumbnail',
//         'revisions',
//       ),
//       'taxnonomies' => array('category','post_tag'),
//       'menu_position' => 5 ,
//       'exclude_from_search' => false
//   );
// }